import React from 'react';
import { Mail, Phone, MapPin } from 'lucide-react';

const Contact = () => {
  return (
    <div id="contact" className="bg-gray-50 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">联系我们</h2>
          <p className="mt-2 text-lg leading-8 text-gray-600">
            有任何问题都可以通过以下方式联系我们
          </p>
        </div>
        <div className="mx-auto mt-16 grid max-w-4xl grid-cols-1 gap-8 sm:grid-cols-3">
          <div className="flex flex-col items-center">
            <Mail className="h-8 w-8 text-blue-600" />
            <h3 className="mt-4 text-base font-semibold text-gray-900">邮箱</h3>
            <p className="mt-2 text-base leading-7 text-gray-600">contact@businessclub.com</p>
          </div>
          <div className="flex flex-col items-center">
            <Phone className="h-8 w-8 text-blue-600" />
            <h3 className="mt-4 text-base font-semibold text-gray-900">电话</h3>
            <p className="mt-2 text-base leading-7 text-gray-600">123-456-7890</p>
          </div>
          <div className="flex flex-col items-center">
            <MapPin className="h-8 w-8 text-blue-600" />
            <h3 className="mt-4 text-base font-semibold text-gray-900">地址</h3>
            <p className="mt-2 text-base leading-7 text-gray-600">大学路123号 学生活动中心</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;